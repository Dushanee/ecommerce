<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body {
  margin: 0 auto;
  max-width: 800px;
  padding: 0 20px;
}

.container {
    border: 2px solid #dedede;
    background-color: #f1f1f1;
    border-radius: 5px;
    padding: 10px;
    width: 66%;
    margin: 22px 0px 18px 2%;
}

.darker {
    border-color: #ccc;
    background-color: #ddd;
    width: 66%;
    margin-left: 29%;
}

.container::after {
  content: "";
  clear: both;
  display: table;
}

.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}

.time-left {
  float: left;
  color: #999;
}

.sendmsg{
  position: absolute;
  margin-top: 38%;
}

#msgbox{
  width: 50%;
    height: 65%;
    border: 2px solid red;
    overflow-y: scroll;
    position: absolute;
    margin-top: 6%;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: flex-start;
    align-items: flex-start;
}
#senderID{
  display: none;
}
#recevierID{
  display: none;
}
.receiverPic{
  width: 70px;
  height: 66px;
  border-radius: 50px;
  padding: 9px 8px 0px 8px;
}
.receiverInfo{
  display: inline-flex;
  margin-left: 0px;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  flex-wrap: wrap;
}

</style>
</head>
<body>

<?php

     
if(isset($_POST["senderID"]) && isset($_POST["receiverID"])){
  $senderID = $_POST["senderID"];
  //echo $senderID."<br>";
  $receiverID = $_POST["receiverID"];  
  //echo $receiverID."<br>";
  $cust_id = $_POST["picID"];
}
require '../connection.php';

$sql = "SELECT cust_fname, cust_pro_pic from customers WHERE cust_id = $cust_id";
$result = mysqli_query($connection,$sql);

if($result == true){
  if(mysqli_num_rows($result)>0){
    while($row = mysqli_fetch_array($result)){
      $custName = $row['cust_fname'];
      $CustProPic = $row['cust_pro_pic'];
    }
  }
}

?>

<div id="msgbox">
<div class="receiverInfo"> 
  <img class="receiverPic" src="../../../../public/customer/image/images1/ProfilePic/<?php echo $CustProPic ?>">
  <p class="receiverName"><?php echo $custName ?></p>
 </div>
</div>

<div class="sendmsg">
  MSG<input type="text" name="msg" id="msg"><br>
  <button id="sendMsg" onclick="sendData()">Send Data</button>
</div>


  <p id="senderID"><?php echo $receiverID ?></p><br>
  <p id="recevierID"><?php echo $senderID ?></p>


<script>

      function sendData(){  //send data to database

        var msg = document.getElementById("msg").value;
        var senderID = document.getElementById("senderID").innerHTML;
        var recevierID = document.getElementById("recevierID").innerHTML;

        var xhr = new XMLHttpRequest();
        xhr.open("GET", "check3.php?data1="+msg+"&"+"data2="+senderID+"&"+"data3="+recevierID, false);
        xhr.onreadystatechange = function() {
          if(xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);
          }
        }
        xhr.send();

        document.getElementById("msg").value = "";
      }
       

      var sendMsg = document.getElementById("sendMsg");
      var msgbox = document.getElementById("msgbox");

      sendMsg.addEventListener('click', function(){  //bring scroll bar to bottom after sending message
        setTimeout(function() {
          msgbox.scrollTo({ top: msgbox.scrollHeight, behavior: 'smooth' });
        },1000)
      })
      
      function passmsg() {//get data from database and show message

         
        var senderID = document.getElementById("senderID").innerHTML;
        //console.log(senderID);
        var recevierID = document.getElementById("recevierID").innerHTML;
        //console.log(recevierID);

        xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", "check1.php?data2="+senderID+"&"+"data3="+recevierID, false);
        xmlhttp.send(null);

        let responseArray = xmlhttp.responseText.split('<brk>');
        //console.log(responseArray);

        if (responseArray.length > 1) { // check if there is data to show

          arrlength = responseArray.length;
          numofdata = (arrlength - 1) / 4;

          var ArrsenderID = 1;
          var msg = 3;
          var fieldcount = 0;
          var msgbox = document.getElementById('msgbox');

          var senderID   = document.getElementById("senderID").innerHTML;
          //console.log(senderID);
          var recevierID = document.getElementById("recevierID").innerHTML;
          //console.log(recevierID);

        for (var i = 0; i < numofdata; i++) {

          if (responseArray[ArrsenderID] == senderID) {
           if (!document.getElementById(responseArray[fieldcount])) { // check if element already exists
            var msgbx1 = document.createElement("div");
            msgbx1.id = responseArray[fieldcount];
            msgbx1.classList.add("container","darker");
            msgbox.appendChild(msgbx1);
        }
        document.getElementById(responseArray[fieldcount]).innerHTML = responseArray[msg];
       }

        if (responseArray[ArrsenderID] == recevierID) {
         if (!document.getElementById(responseArray[fieldcount])) { // check if element already exists
          var msgbx2 = document.createElement("div");
          msgbx2.id = responseArray[fieldcount];
          msgbx2.classList.add("container");
          msgbox.appendChild(msgbx2);
         }
        document.getElementById(responseArray[fieldcount]).innerHTML = responseArray[msg];
        }
        fieldcount = fieldcount + 4;
        ArrsenderID = ArrsenderID + 4;
        msg = msg + 4;
       }
      }
     }

passmsg();


setInterval(function () {
  passmsg();
}, 1000);

     
      function updateReadList(){
        
        var senderID = document.getElementById("senderID").innerHTML;
        var recevierID = document.getElementById("recevierID").innerHTML;
  
        //console.log(senderID);
        //console.log(recevierID);
        var pagePath = window.location.pathname;
        //console.log(pagePath);

        var check = pagePath.includes("check5.php");
        //console.log(check);
        
        if(check == true && senderID.length > 0 && recevierID.length > 0) {
          //console.log("inside loop");
          var xhr = new XMLHttpRequest();
          xhr.open("GET", "check4.php?data1="+check+"&"+"data2="+senderID+"&"+"data3="+recevierID, false);
          xhr.onreadystatechange = function() {
            if(xhr.readyState == 4 && xhr.status == 200) {
              //console.log(xhr.responseText);
           }
          }
          xhr.send();
         }

      }
      
       updateReadList();

setInterval(function () {
  updateReadList();
}, 1000);
     
    
</script>

</body>
</html>
